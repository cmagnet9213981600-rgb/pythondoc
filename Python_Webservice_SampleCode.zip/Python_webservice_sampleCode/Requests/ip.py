﻿import requests

url = "https://mydnspanel.com/webservice/ip"

payload = {}
headers = {}

response = requests.request("POST", url, headers=headers, data=payload)

print(response.text)