﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'newContact',
'phoneId': '123456',
'cNumber': '9123456789',
'cFields': '{"FJa1234":"test"}'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)