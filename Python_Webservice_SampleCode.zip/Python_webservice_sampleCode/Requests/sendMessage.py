﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'send',
'from': '9850004988',
'text': 'This is a test message.',
'receivers': '989120000000'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)