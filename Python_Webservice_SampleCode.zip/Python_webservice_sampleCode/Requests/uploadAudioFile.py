﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'uploadAudio',
'fileData': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)