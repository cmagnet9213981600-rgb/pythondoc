﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'send',
'type': '2',
'fileData': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
'receivers': '989120000000'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)