﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'patternData',
'patternId': '0'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)