﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'sendServices',
'from': '9850009880000',
'textCode': '0',
'textData': '{"{code}": "1234"}',
'receivers': '989120000000'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)