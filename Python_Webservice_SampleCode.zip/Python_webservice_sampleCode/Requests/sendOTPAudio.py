﻿import requests

url = "https://mydnspanel.com/webservice/server"

payload = {'action': 'sendOTP',
'type': '2',
'digits': '4',
'round': '1',
'appID': '0',
'receivers': '989120000000'}
files=[

]
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)