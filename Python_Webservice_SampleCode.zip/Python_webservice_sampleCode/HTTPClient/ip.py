﻿import http.client

conn = http.client.HTTPSConnection("mydnspanel.com")
payload = ''
headers = {}
conn.request("POST", "/webservice/ip", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))