﻿import http.client
import mimetypes
from codecs import encode

conn = http.client.HTTPSConnection("mydnspanel.com")
dataList = []
boundary = 'wL36Yn8afVp8Ag7AmP8qZ0SA4n1v9T'
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=action;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("send"))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=from;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("9850004988"))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=text;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("This is a test message."))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=receivers;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("989120000000"))
dataList.append(encode('--'+boundary+'--'))
dataList.append(encode(''))
body = b'\r\n'.join(dataList)
payload = body
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  'Content-type': 'multipart/form-data; boundary={}'.format(boundary)
}
conn.request("POST", "/webservice/server", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))