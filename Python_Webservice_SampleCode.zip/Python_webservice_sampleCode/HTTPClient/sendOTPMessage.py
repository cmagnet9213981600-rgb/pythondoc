﻿import http.client
import mimetypes
from codecs import encode

conn = http.client.HTTPSConnection("mydnspanel.com")
dataList = []
boundary = 'wL36Yn8afVp8Ag7AmP8qZ0SA4n1v9T'
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=action;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("sendOTP"))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=digits;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("4"))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=round;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("1"))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=appID;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("0"))
dataList.append(encode('--' + boundary))
dataList.append(encode('Content-Disposition: form-data; name=receivers;'))

dataList.append(encode('Content-Type: {}'.format('text/plain')))
dataList.append(encode(''))

dataList.append(encode("989120000000"))
dataList.append(encode('--'+boundary+'--'))
dataList.append(encode(''))
body = b'\r\n'.join(dataList)
payload = body
headers = {
  'Authorization': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  'Cookie': 'X0A00X1=2f7qnre8857p2kvdvqq0jhns6a',
  'Content-type': 'multipart/form-data; boundary={}'.format(boundary)
}
conn.request("POST", "/webservice/server", payload, headers)
res = conn.getresponse()
data = res.read()
print(data.decode("utf-8"))